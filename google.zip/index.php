<?php
   
   include("mheader.php");

    if(isset($_SESSION['q']))
   $qu = $_SESSION['q'];
   else
   $qu = '';

   if(isset($_SESSION['userid']))
   {
      echo "<ul>";
      echo "<li onclick='courses()'>Courses</li>";
      echo "<li>Blog</li>";
      echo "</ul>";
?>
   



<?php
     
    

   }
   else{
?>
<?php
   }
?>
<html>
  <head>
    <title>KSC</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="typeahead.min.js"></script>
    <script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});

function showUser() {
    str = document.getElementById("typeahead").value;
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        
        document.getElementById("f1").src = "getuser.php?q="+str;

        //xmlhttp.open("GET","getuser.php?q="+str,true);
        //xmlhttp.send();


    }
}

  function courses(){
    document.getElementById("f1").src = "courseList.php";
  }
    </script>
    <style type="text/css">

    #f1{
      width: 90%;
      height:600px;
      margin-left: 4%;
      margin-right:4%;
      margin-top: 5px;
      border: none;
    }
.bs-example{
	font-family: sans-serif;
	position: relative;
	margin-top: 10px;
  margin-bottom: 10px;
  margin-left: 5%;
  width:50%;
}
.typeahead, .tt-query, .tt-hint {
	border: 2px solid #CCCCCC;
	border-radius: 8px;
	font-size: 24px;
	height: 30px;
	line-height: 30px;
	outline: medium none;
	padding: 8px 12px;
	width: 396px;
}
.typeahead {
	background-color: #FFFFFF;
}
.typeahead:focus {
	border: 2px solid #0097CF;
}
.tt-query {
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
}
.tt-hint {
	color: #999999;
}
.tt-dropdown-menu {
	background-color: #FFFFFF;
	border: 1px solid rgba(0, 0, 0, 0.2);
	border-radius: 8px;
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	margin-top: 12px;
	padding: 8px 0;
	width: 422px;
}
.tt-suggestion {
	font-size: 24px;
	line-height: 24px;
	padding: 3px 20px;
}
.tt-suggestion.tt-is-under-cursor {
	background-color: #0097CF;
	color: #FFFFFF;
}
.tt-suggestion p {
	margin: 0;
}

.theme{
  background: yellow;
  padding: 5px;
  width:90%;
  margin-right: 4%;
  margin-left: 4%;
  box-shadow: 4px 4px;
  margin-bottom: 5px;
  margin-top: 2px;
}

li{
    display: inline;
    background: lightblue;
    padding: 2px;
    margin: 5px;
}

ul{
    background: green;
    height: 40px;
    padding: 10px;
}

</style>
  </head>
  <body>
  <div class=".col-md-6">
    <div class="panel panel-default">
    <div class="bs-example">
        
        <table><tr>
       <td> <input type="text" id ="typeahead" name="typeahead" class="form-control" autocomplete="off" spellcheck="false" value="<?php echo 'My'; ?>" onkeydown="showUser()"></td>
       <td><Button onclick="showUser()">Search</button></td>
       </tr></table>
    </div>
  </div>
  </div>
  </div>
  <iframe id="f1" src=""></iframe>
  </body>
</html>
