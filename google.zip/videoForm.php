
<?php

        require_once('header.php');
 ?>

<div class='form-group'>
<form action='videoInsert.php' method='post'>
<input class='form-control' type='text' name='caption' placeholder='Enter caption'>
<input class='form-control' type='text' name='source' placeholder='Enter source'>
<input class='form-control' type='text' name='obid' placeholder='Enter obid'>
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>
.form-group{
    width:80%;
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}

</style>

</head>
<input class='btn btn-primary' type='submit' name='submit' value='Add'>
</div>