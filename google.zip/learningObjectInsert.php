<?php
require_once('header.php');
session_start();

$cloid = $_GET['cloid'];
$url = "learningObjectlist.php?cloid=".$cloid;

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$CLO = $_POST['CLO'];
$Title = $_POST['Title'];
$KSC = $_POST['KSC'];
$LobjBody = $_POST['LobjBody'];
$userid = $_SESSION['userid'];

$sql = "Insert Into learningObject ( CLO, Title, KSC, body, userid) values ('$CLO','$Title','$KSC','$LobjBody','$userid')";

echo $sql;
$result = dbcon('online',$sql);


header('Location: ' . $url);
}
?>