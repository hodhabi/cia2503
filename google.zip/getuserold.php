<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

<style>
.table{
    width:90%;
}
</style>
</head>
<body>

<?php
$q = $_GET['q'];

$con = mysqli_connect('localhost','root','','online');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"ajax_demo");
$sql="select * from learningObject where Title LIKE '%{$q}%' or KSC LIKE '%{$q}%'";
$result = mysqli_query($con,$sql);
echo "<div class='container'>";
echo "<table class='table'>";
$i = 0;
while($row = mysqli_fetch_array($result)) {
    $idv = $row['id'];
if($i==0){
echo "<tr class='success'>";
echo " <th>   </th>";
echo " <th> Title  </th>";
echo " <th> KSC  </th>";
echo "</tr>";
}
$i = $i + 1;
$cloid = $row['CLO'];
echo "<tr>";
echo "<td><A class='btn btn-success' href='learningObjectView.php?id=$idv&cloid=$cloid'>View</A>";

//echo "<A class='btn btn-info' href='learningObjectFormEdit.php?id=$idv&cloid=$cloid'>Edit</A>";

echo "<td>" . $row['Title'] . "</td>";
echo "<td>" . $row['KSC'] . "</td>";
echo "</tr>";
}

    
    
    
    /*
    echo "<tr>";
    echo "<td>" . $row['Title'] . "</td>";
    echo "<td>" . $row['KSC'] . "</td>";
    echo "</tr>";*/

echo "</table>";
echo "</div>";
mysqli_close($con);
?>
</body>
</html>