<?php
require_once('header.php');

include('dbconnect.php');

$id = $_GET['id'];
$cloid = $_GET['cloid'];
$url = "learningObjectList.php?cloid=" . $cloid;

$sql = "Delete from learningObject  where id=$id ";
$result = dbcon('online',$sql);


header('Location: '. $url);
?>