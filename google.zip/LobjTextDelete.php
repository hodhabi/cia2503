<?php
require_once('header.php');

include('dbconnect.php');

$id = $_GET['id'];
$sql = "Delete from LobjText  where id=$id ";
$result = dbcon('online',$sql);


header('Location:  LobjTextList.php');
?>