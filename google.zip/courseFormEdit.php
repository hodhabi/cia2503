
<?php

include('dbconnect.php');

$id = $_GET['id'];

$sql = "select * from course where id='$id'";

$result = dbcon('online',$sql);

if ($result->num_rows > 0) {

  $row = $result->fetch_assoc();

  ?>

<div class='form-group'>
<form action='courseEdit.php' method='post'>
<input class='form-control' type='text' name='id' value="<?php echo $row['id']; ?>">
<input class='form-control' type='text' name='code' value="<?php echo $row['code']; ?>">
<input class='form-control' type='text' name='Title' value="<?php echo $row['Title']; ?>">
<input class='form-control' type='hidden' name='userid' value="<?php echo $row['userid']; ?>">
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>
.form-group{
    width:80%;
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}

</style>

</head>
<input class='btn btn-primary' type='submit' name='submit' value='Update'>
</div>
<?php
}
?>
