<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$title = $_POST['title'];
$vtitle = mysql_real_escape_string($title);
$body = $_POST['body'];
$vbody = mysql_real_escape_string($body);
$obid = $_POST['obid'];
$vobid = mysql_real_escape_string($obid);
$sql = "Update LobjText Set  title='$vtitle', body='$vbody', obid='$vobid' where id=$id ";
$result = dbcon('online',$sql);


header('Location:  LobjTextList.php');
}
?>