
<?php

        include('dbconnect.php');
        $cloid = $_GET['cloid'];
        $url = "learningObjectInsert.php?cloid=".$cloid;

 ?>
 <div class="container">
<div class='form-group'>
<form action='<?php echo $url; ?>' method='post'>
<input class='form-control' type='hidden' name='CLO' value='<?php echo $cloid; ?>'>
<div class="panel panel-default">
<div class="panel-heading"><b>Learning Outcome</b></div>
<div class="panel-body"><?php CLOText($cloid); ?></div>
</div>
<input class='form-control' type='text' name='Title' placeholder='Enter Title for your learning object'>
<div class="panel panel-default">
<div class="panel-heading"><b>Knowledge, Skills and Comptencies:</b></div>
<div class="panel-body">
<textarea rows="6" cols="80" class='form-control' type='text' name='KSC' placeholder='List knowledge, skills and comptencies that will be covered by this learning object.'></textarea>
</div></div>
<div class="panel panel-default">
<div class="panel-heading"><b>Body of the topic:</b></div>
<div class="panel-body">
<textarea rows="30" cols="80" class='form-control' type='text' name='LobjBody' placeholder='Full text the exaplin the topic'></textarea>
</div></div>
<input class='btn btn-primary' type='submit' name='submit' value='Add'>
</form>
</div>
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>



</style>

<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

<script>
tinymce.init({
  selector: 'textarea',
  theme: 'modern',
  plugins: [
    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
    'searchreplace wordcount visualblocks visualchars code fullscreen',
    'insertdatetime media nonbreaking save table contextmenu directionality',
    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
  ],
  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
  image_advtab: true,
  templates: [
    { title: 'Test template 1', content: 'Test 1' },
    { title: 'Test template 2', content: 'Test 2' }
  ],
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css'
  ]
 });
</script>



</head>

</div>
</div>

<?php
function CLOText($cloid){
$sql = "select * from CLO where id = '$cloid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['description'];
}
?>