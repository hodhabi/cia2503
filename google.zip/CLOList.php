<?php
$conn=mysqli_connect("localhost","root","","online");
session_start();
include("dbconnect.php");



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pagination</title>
<link href="style.css" rel="stylesheet" type="text/css" />

 <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>

<style>


</style>
<script>
function delete_id(id,cid)
{

     if(confirm('Sure To Remove This Record ?'))
     {
        window.location.href='CLODelete.php?id='+id+"&cid="+cid;
     }
}

</script>
</head>

<body>
<?php
$cid = $_GET['cid'];
?>


<h2>Course: <?php echo Coursename($cid); ?></h2>
<h4>Course learning outcomes</h4>

<table class='table'>
<?php



$perpage = 10;
echo "<A class='btn btn-primary' href=CLOform.php?cid=$cid>Add a record</a>";
if(isset($_GET["page"])){
	$page = intval($_GET["page"]);
}
else {
$page = 1;
}
$calc = $perpage * $page;
$start = $calc - $perpage;
if(isset($_SESSION['userid']))
{
  $userid = $_SESSION['userid'];
  $result = mysqli_query($conn, "select * from CLO where courseid ='$cid' Limit $start, $perpage");
}
else
$result = mysqli_query($conn, "select * from CLO Limit $start, $perpage");

$rows = mysqli_num_rows($result);

if($rows){
	$i = 0;
	while($post = mysqli_fetch_assoc($result)) {
?>
<tbody>
<tr class='success'>
<?php

$idv = $post["id"];
echo "<td>";
if(isset($_SESSION['userid']))
{
echo "<A class='btn btn-success' href='CLOFormEdit.php?id=$idv&cid=$cid'>Edit</A>";
echo "<A class='btn btn-success' href='learningObjectList.php?cloid=$idv'>Learning Objects</A>";
}
echo "<p class='btn btn-danger' onclick='delete_id($idv,$cid)'></a>Delete</p>";
echo "</td>";
?>
<td style="font-weight: bold;font-family: arial;"><?php echo $post["description"]; ?></td>
<td style="font-family: arial;padding-left: 20px;"><?php echo $post["NQFLevel"]; ?></td>

</tr>
<?php
}
}
?>

</tbody>
</table>

<table width="400" cellspacing="2" cellpadding="2" align="center">
<tbody>
<tr>
<td align="center">

<?php

if(isset($page))

{

$result = mysqli_query($conn,"select count(*) As Total from CLO where courseid = '$cid'");

$rows = mysqli_num_rows($result);

if($rows)

{

$rs = mysqli_fetch_assoc($result);

$total = $rs["Total"];

}

$totalPages = ceil($total / $perpage);

if($page <=1 ){

echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";

}

else

{

$j = $page - 1;

echo "<span><a id='page_a_link' href='CLOList.php?page=$j'>< Prev</a></span>";

}

for($i=1; $i <= $totalPages; $i++)

{

if($i<>$page)

{

echo "<span><a id='page_a_link' href='CLOList.php?page=$i'>$i</a></span>";

}

else

{

echo "<span id='page_links' style='font-weight: bold;'>$i</span>";

}

}

if($page == $totalPages )

{

echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";

}

else

{

$j = $page + 1;

echo "<span><a id='page_a_link' href='CLOList.php?page=$j'>Next</a></span>";

}

}

?></td>
<td></td>
</tr>
</tbody>
</table>


</body>
</html>
<?php

function Coursename($cid){

$sql = "select * from course where id = '$cid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['code'] . " " . $row['Title'];

}