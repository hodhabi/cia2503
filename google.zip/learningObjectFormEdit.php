<!DOCTYPE html>
<html>
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

<script>
tinymce.init({
  selector: 'textarea',
  theme: 'modern',
  plugins: [
    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
    'searchreplace wordcount visualblocks visualchars code fullscreen',
    'insertdatetime media nonbreaking save table contextmenu directionality',
    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
  ],
  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
  image_advtab: true,
  templates: [
    { title: 'Test template 1', content: 'Test 1' },
    { title: 'Test template 2', content: 'Test 2' }
  ],
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css'
  ]
 });
</script>

  <style>


</style>



</head>
<body>
<?php

include('dbconnect.php');

$id = $_GET['id'];
$cloid = $_GET['cloid'];

$sql = "select * from learningObject where id='$id'";

$result = dbcon('online',$sql);

if ($result->num_rows > 0) {

  $row = $result->fetch_assoc();

  ?>
<div class="container">
<div class="panel panel-default">
<div class="panel-heading"><b>Learning Outcome</b></div>
<div class="panel-body"><?php CLOText($cloid); ?></div>
</div>
<div class='form-group'>
<form action='learningObjectEdit.php' method='post'>
<input class='form-control' type='hidden' name='id' value="<?php echo $row['id']; ?>">
<input class='form-control' type='hidden' name='CLO' value="<?php echo $row['CLO']; ?>">
<input class='form-control' type='text' name='Title' value="<?php echo $row['Title']; ?>">
<div class="panel panel-default">
<div class="panel-heading"><b>Knowledge, Skills and Comptencies:</b></div>
<div class="panel-body">
<textarea id=”NicEdit” rows="6" cols="80" class='form-control' type='text' name='KSC'><?php echo $row['KSC']; ?></textarea>
</div></div>

<div class="panel panel-default">
<div class="panel-heading"><b>The main topic:</b></div>
<div class="panel-body">
<textarea rows="20" cols="80" class='form-control' type='text' name='body'> <?php echo $row['body']; ?></textarea>
</div></div>
<input class='btn btn-primary' type='submit' name='submit' value='Update'>
</form>
</div>
</div>
<?php
}
?>
</body>
</html>
<?php
function CLOText($cloid){
$sql = "select * from CLO where id = '$cloid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['description'];
}
?>
