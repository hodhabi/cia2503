-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2016 at 01:39 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Online`
--

-- --------------------------------------------------------

--
-- Table structure for table `CLO`
--

CREATE TABLE `CLO` (
  `id` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `description` text NOT NULL,
  `NQFLevel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CLO`
--

INSERT INTO `CLO` (`id`, `courseid`, `description`, `NQFLevel`) VALUES
(1, 1, '<b>CLO 1</b>- Describe the concepts and technologies underlying web applications including emerging trends and technologies, client-side and server-side scripting, and the concepts of dynamic data and functionality.', 5),
(7, 1, 'CLO 2- Create rich web-based user interfaces using current standards-compliant client-side web technologies.', 5),
(8, 1, 'CLO 3- Compose functional programs for the web using HTML 5 and JavaScript programming language (including JavaScript libraries)', 5);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `code`, `Title`, `userid`) VALUES
(1, 'CIA-2503', 'Web Application Development', 0);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `caption` varchar(100) NOT NULL,
  `source` varchar(100) NOT NULL,
  `obid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `learningObject`
--

CREATE TABLE `learningObject` (
  `id` int(11) NOT NULL,
  `CLO` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `KSC` text NOT NULL,
  `body` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `video` varchar(100) NOT NULL,
  `links` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `learningObject`
--

INSERT INTO `learningObject` (`id`, `CLO`, `Title`, `KSC`, `body`, `image`, `video`, `links`) VALUES
(1, 1, 'My first learning Object', '<p><strong>Understand</strong> the functions of server side and client side technology, list number of server side and client side technologies, compare at least 3 client side and 3 serve side technologies.</p>\r\n<p><strong>Hamad</strong> Odhabi</p>\r\n<p><img src="http://news.hct.ac.ae/content/uploads/sites/2/2013/03/Mariaandfatemafromumaldarda.jpg" alt="HCT" width="358" height="262" /></p>', '<h1 style="text-align: center;"><strong>Introduction</strong></h1>\r\n<p><span style="background-color: #ffff00;">2016-12-20</span></p>\r\n<p>&nbsp;</p>\r\n<pre class="language-javascript"><code>function CallSum()\r\n{\r\n  return sum;\r\n}</code></pre>\r\n<p><a href="http://www.hct.ac.ae">This is a great example of using PhP.</a></p>\r\n<p>&nbsp;<iframe src="https://www.youtube.com/embed/tXFPaAE4UtM" width="560" height="315" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>\r\n<p><iframe src="https://www.youtube.com/embed/FcA1KXSIAKs" width="560" height="315" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>', 'jvbjdsjds', 'jgfjdsjgsd', '<p>HCT</p>'),
(2, 7, 'dsgfgdfg', 'fdgdfgdfgdf', 'fdgdfgdfgdfgd', '', '0', '0'),
(3, 1, 'jjvvjhv', '<b>Welcome</b>  Thank you.', ' ', '', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `LobjText`
--

CREATE TABLE `LobjText` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `obid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `caption` varchar(100) NOT NULL,
  `source` varchar(100) NOT NULL,
  `obid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CLO`
--
ALTER TABLE `CLO`
  ADD PRIMARY KEY (`id`),
  ADD KEY `courseid` (`courseid`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `obid` (`obid`);

--
-- Indexes for table `learningObject`
--
ALTER TABLE `learningObject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `CLO` (`CLO`);

--
-- Indexes for table `LobjText`
--
ALTER TABLE `LobjText`
  ADD PRIMARY KEY (`id`),
  ADD KEY `textid` (`obid`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`),
  ADD KEY `textid` (`obid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CLO`
--
ALTER TABLE `CLO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `learningObject`
--
ALTER TABLE `learningObject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `LobjText`
--
ALTER TABLE `LobjText`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `CLO`
--
ALTER TABLE `CLO`
  ADD CONSTRAINT `clo_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `course` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `image_ibfk_1` FOREIGN KEY (`obid`) REFERENCES `learningObject` (`id`);

--
-- Constraints for table `learningObject`
--
ALTER TABLE `learningObject`
  ADD CONSTRAINT `learningobject_ibfk_1` FOREIGN KEY (`CLO`) REFERENCES `CLO` (`id`);

--
-- Constraints for table `LobjText`
--
ALTER TABLE `LobjText`
  ADD CONSTRAINT `lobjtext_ibfk_1` FOREIGN KEY (`obid`) REFERENCES `learningObject` (`id`);

--
-- Constraints for table `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`obid`) REFERENCES `learningObject` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
