<!DOCTYPE html>
<html>
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

<script>
tinymce.init({
  selector: 'textarea',
  theme: 'modern',
  plugins: [
    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
    'searchreplace wordcount visualblocks visualchars code fullscreen',
    'insertdatetime media nonbreaking save table contextmenu directionality',
    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
  ],
  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
  image_advtab: true,
  templates: [
    { title: 'Test template 1', content: 'Test 1' },
    { title: 'Test template 2', content: 'Test 2' }
  ],
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css'
  ]
 });
</script>

  <style>
.form-group{
    width:80%;
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}

#topict{
    border: 1px solid;
    background: lightgreen;
    text-align: center;
}
</style>



</head>
<body>
<?php

include('dbconnect.php');

$id = $_GET['id'];

$sql = "select * from learningObject where id='$id'";

$result = dbcon('online',$sql);

if ($result->num_rows > 0) {

  $row = $result->fetch_assoc();

  ?>
<div class="container">
<div id="topict">
<h2><?php echo $row['Title']; ?></h2>
</div>
<div class="panel panel-default">
<div class="panel-heading"><h3>Learning Outcome:</h3></div>
<div class="panel-body"><?php echo CLOText($row['CLO']); ?></div>
</div>

<div class="panel panel-default">
<div class="panel-heading"><h3>Knowledge, Skills and Comptencies:</h3></div>
<div class="panel-body"><?php echo $row['KSC']; ?></div>
</div>
<div class="panel panel-default">
<div class="panel-heading"><h3><?php echo $row['Title']; ?></h3></div>
<div class="panel-body"><?php echo $row['body']; ?></div>
</div>

</div>
<?php
}
function CLOText($cloid){
$sql = "select * from CLO where id = '$cloid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['description'];
}
?>

</body>
</html>
