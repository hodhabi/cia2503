
<?php
  session_start();
 ?>
<HEAD>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
 .head{
     display: inline;
     margin: auto;
     text-align: center;
 }
 #h{
     font-size: 24px;
     margin: auto;
     text-align: center;
 }
 
</style>

</HEAD>
<div id='header'>


<?php
echo "<table><tr>";
   if(isset($_SESSION['userid']))
   {
    $username = $_SESSION['userfname'];
    
    echo "<p id='h'>Outcomes based Learning</p>";
    echo "<p class='head'>" . $username . " <a href='logout.php'>Logout</A></p>";    

   }
   else
   {
   echo "<p id='h'>Outcomes based Learning</p>";
   echo "<p class='head'><a href='glogin/index.php'>Login with Google</A></p>";
   }
?>

</tr></table>

</div>


<style>

#header{


    background: silver;
    height: 100px;
    margin: auto;
    text-align: center;


}






</style>


