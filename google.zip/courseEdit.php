<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$code = $_POST['code'];
$vcode = mysql_real_escape_string($code);
$Title = $_POST['Title'];
$vTitle = mysql_real_escape_string($Title);
$userid = $_POST['userid'];
$vuserid = mysql_real_escape_string($userid);
$sql = "Update course Set  code='$vcode', Title='$vTitle', userid='$vuserid' where id=$id ";
$result = dbcon('online',$sql);


header('Location:  courseList.php');
}
?>