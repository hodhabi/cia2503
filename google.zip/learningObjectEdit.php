<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$CLO = $_POST['CLO'];
$body = $_POST['body'];

$vCLO = mysql_real_escape_string($CLO);
$Title = $_POST['Title'];
$vTitle = mysql_real_escape_string($Title);
$KSC = $_POST['KSC'];
$vKSC = mysql_real_escape_string($KSC);
$sql = "Update learningObject Set  CLO='$vCLO', Title='$vTitle', KSC='$vKSC', body='$body' where id=$id ";
$result = dbcon('online',$sql);


header('Location:  learningObjectList.php?cloid='.$vCLO);
}
?>