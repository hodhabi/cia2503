
<?php

include('dbconnect.php');

$id = $_GET['id'];

$cid = $_GET['cid'];

$url = "CLOEdit.php?cid=" . $cid;

$sql = "select * from CLO where id='$id'";

$result = dbcon('online',$sql);

if ($result->num_rows > 0) {

  $row = $result->fetch_assoc();

  ?>

<div class='form-group'>
<form action='<?php echo $url; ?>' method='post'>
<input class='form-control' type='hidden' name='id' value="<?php echo $row['id']; ?>">
<h4><?php courseTitle($cid); ?></h4>
<p>Edit the course learning outcome:</p>
<p>Learning outcome</p><br>
<input class='form-control' type='hidden' name='courseid' value="<?php echo $row['courseid']; ?>">
<input class='form-control' type='text' name='description' value="<?php echo $row['description']; ?>">
<br><p>National qualifiction level:</p>
<input class='form-control' type='text' name='NQFLevel' value="<?php echo $row['NQFLevel']; ?>">
<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>
.form-group{
    width:80%;
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}

</style>

</head>
<input class='btn btn-primary' type='submit' name='submit' value='Update'>
</div>
<?php
}
?>

<?php
function courseTitle($cid){
$sql = "select * from course where id = '$cid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['code'] . " " . $row['Title'];
}
?>