<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$code = $_POST['code'];
$Title = $_POST['Title'];
$userid = $_POST['userid'];
$sql = "Insert Into course ( code, Title, userid) values ('$code','$Title','$userid')";
$result = dbcon('online',$sql);


header('Location: courselist.php');
}
?>