<?php
$conn=mysqli_connect("localhost","root","","online");
include("dbconnect.php");
session_start();

if(isset($_GET["q"])){
	$_SESSION['q'] = $_GET["q"];
}

$q = $_SESSION['q'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pagination</title>
<link href="style.css" rel="stylesheet" type="text/css" />

 <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  
</head>

<body>

<table class='table'>
<?php

$perpage = 10;

$cloid = $_GET['cloid'];

echo "<A class='btn btn-primary' href=learningObjectform.php?cloid=$cloid>Add a record</a>";

if(isset($_GET["page"])){
	$page = intval($_GET["page"]);
}
else {
$page = 1;
}
$calc = $perpage * $page;
$start = $calc - $perpage;
$result = mysqli_query($conn, "select * from learningObject where CLO=$cloid Limit $start, $perpage");

$rows = mysqli_num_rows($result);

if($rows){
	$i = 0;
	while($post = mysqli_fetch_assoc($result)) {
?>
<tbody>
<tr class='success'>
<?php
$cloid = $post["CLO"];
$idv = $post["id"];

echo "<td><A class='btn btn-success' href='learningObjectView.php?id=$idv&cloid=$cloid' target='_parent'>View</A>";
 if(isset($_SESSION['userid']))
   {
     echo "<A class='btn btn-info' href='learningObjectFormEdit.php?id=$idv&cloid=$cloid'>Edit</A>";
   }
?>
<td style="font-weight: bold;font-family: arial;"><?php echo $post["Title"]; ?></td>
<td style="font-family: arial;padding-left: 20px;"><?php echo $post["KSC"]; ?></td>
<td style="font-family: arial;padding-left: 20px;"><?php echo Username($post["userid"]); ?></td>


</tr>
<?php
}
}
?>

</tbody>
</table>

<table width="400" cellspacing="2" cellpadding="2" align="center">
<tbody>
<tr>
<td align="center">

<?php

if(isset($page))

{

$result = mysqli_query($conn,"select count(*) As Total from learningObject where CLO=$cloid");

$rows = mysqli_num_rows($result);

if($rows)

{

$rs = mysqli_fetch_assoc($result);

$total = $rs["Total"];

}

$totalPages = ceil($total / $perpage);

if($page <=1 ){

echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";

}

else

{

$j = $page - 1;

echo "<span><a id='page_a_link' href='learningObjectList.php?page=$j'>< Prev</a></span>";

}

for($i=1; $i <= $totalPages; $i++)

{

if($i<>$page)

{

echo "<span><a id='page_a_link' href='learningObjectList.php?page=$i'>$i</a></span>";

}

else

{

echo "<span id='page_links' style='font-weight: bold;'>$i</span>";

}

}

if($page == $totalPages )

{

echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";

}

else

{

$j = $page + 1;

echo "<span><a id='page_a_link' href='learningObjectList.php?page=$j'>Next</a></span>";

}

}

?></td>
<td></td>
</tr>
</tbody>
</table>


</body>
</html>

<?php

function Username($uid){

$sql = "select * from google_users where google_id = '$uid'";
$result = dbcon('online',$sql);
$row = $result->fetch_assoc();
echo $row['google_name'];

}
?>