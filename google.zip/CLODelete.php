<?php
require_once('header.php');

include('dbconnect.php');

$cid = $_GET['cid'];

$url = "CLOList.php?cid=" . $cid;

$id = $_GET['id'];
$sql = "Delete from CLO  where id=$id ";
$result = dbcon('online',$sql);


header('Location: ' . $url);
?>