<?php
  session_start();
  if(isset($_SESSION['userid']))
  {

?>

<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>
.table{
    width:100%;
    margin-left:5%;
    margin-right:5%;
    margin-top:20px;
}

 #f1{
      width: 90%;
      height:600px;
      margin-left: 4%;
      margin-right:4%;
      margin-top: 5px;
      border: none;
    }

tr:active{
      background-color: yellow;
}

</style>

<script>

function delete_id(id)
{

     if(confirm('Sure To Remove This Record ?'))
     {
        window.location.href='courseDelete.php?id='+id;
     }
}

function CLOList(idv){
  document.getElementById('f1').src = 'CLOList.php?cid=' + idv;
}

</script>


</head>
<?php
include('dbconnect.php');
echo "<A class='btn btn-primary' href=courseform.php>Add a record</a>";
$sql = "select * from course ";
$result = dbcon('online',$sql);
if($result->num_rows > 0){
echo "<table class='table'>";
$i = 0;
while($row = $result->fetch_assoc()){
$idv = $row['id'];
if($i==0){
echo "<tr class='success'>";
echo " <th>   </th>";
echo " <th> Course code  </th>";
echo " <th> Course title  </th>";
echo "</tr>";
}
$i = $i + 1;
echo "<tr>";
echo "<td>";
echo "<A class='btn btn-success' href='courseFormEdit.php?id=$idv'>Edit</A>";
echo "<p class='btn btn-danger' onclick='delete_id($idv)'></a>Delete</p>";
echo "<A class='btn btn-success' href='CLOList.php?cid=$idv'>Learning Outcomes</A>";
//echo "<button class='btn btn-success' onclick='CLOList($idv)'>Learning Outcomes</button>";
echo "</td>";
echo "<td>" . $row['code'] . "</td>";
echo "<td>" . $row['Title'] . "</td>";
echo "</tr>";
}
}
echo '</table>';
  }
  else
  header("location: index.php");
?>
<hr>
<iframe id="f1" src=""></iframe>
