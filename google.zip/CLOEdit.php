<?php
require_once('header.php');

$cid = $_GET['cid'];

$url = "CLOList.php?cid=" . $cid;

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$courseid = $_POST['courseid'];
$vcourseid = mysql_real_escape_string($courseid);
$description = $_POST['description'];
$vdescription = mysql_real_escape_string($description);
$NQFLevel = $_POST['NQFLevel'];
$vNQFLevel = mysql_real_escape_string($NQFLevel);
$sql = "Update CLO Set  courseid='$vcourseid', description='$vdescription', NQFLevel='$vNQFLevel' where id=$id ";
$result = dbcon('online',$sql);


header('Location: ' . $url);
}
?>