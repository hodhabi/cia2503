

<?php

        $cloid = $_GET['cloid'];
 ?>


<head>
  <title>SIS</title>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
  <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  

  <style>
.table{
    width:80%;
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}

</style>

<script>

function delete_id(id,cloid)
{

     if(confirm('Sure To Remove This Record ?'))
     {
        window.location.href='learningObjectDelete.php?id='+id+'&cloid='+cloid;
     }
}

</script>


</head>
<?php
include('dbconnect.php');
echo "<A class='btn btn-primary' href=learningObjectform.php?cloid=$cloid>Add a record</a>";
$sql = "select * from learningObject where CLO = '$cloid'";
$result = dbcon('online',$sql);
if($result->num_rows > 0){
echo "<table class='table'>";
$i = 0;
while($row = $result->fetch_assoc()){
$idv = $row['id'];
if($i==0){
echo "<tr class='success'>";
echo " <th>   </th>";
echo " <th> Title  </th>";
echo " <th> KSC  </th>";
echo "</tr>";
}
$i = $i + 1;
echo "<tr>";
echo "<td><A class='btn btn-success' href='learningObjectView.php?id=$idv&cloid=$cloid'>View</A>";
echo "<A class='btn btn-info' href='learningObjectFormEdit.php?id=$idv&cloid=$cloid'>Edit</A>";
echo "<p class='btn btn-danger' onclick='delete_id($idv,$cloid)'></a>Delete</p></td>";

echo "<td>" . $row['Title'] . "</td>";
echo "<td>" . $row['KSC'] . "</td>";
echo "</tr>";
}
}
echo '</table>';
?>
