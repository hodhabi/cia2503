<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$caption = $_POST['caption'];
$source = $_POST['source'];
$obid = $_POST['obid'];
$sql = "Insert Into image ( caption, source, obid) values ('$caption','$source','$obid')";
$result = dbcon('online',$sql);


header('Location: imagelist.php');
}
?>