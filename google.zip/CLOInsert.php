<?php
require_once('header.php');

$cid = $_GET['cid'];

$url = "CLOlist.php?cid=" . $cid;

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$courseid = $_POST['courseid'];
$description = $_POST['description'];
$NQFLevel = $_POST['NQFLevel'];
$sql = "Insert Into CLO ( courseid, description, NQFLevel) values ('$courseid','$description','$NQFLevel')";
$result = dbcon('online',$sql);


header('Location: '. $url);
}
?>