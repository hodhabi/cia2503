<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$title = $_POST['title'];
$body = $_POST['body'];
$obid = $_POST['obid'];
$sql = "Insert Into LobjText ( title, body, obid) values ('$title','$body','$obid')";
$result = dbcon('online',$sql);


header('Location: LobjTextlist.php');
}
?>