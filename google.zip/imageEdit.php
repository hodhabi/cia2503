<?php
require_once('header.php');

include('dbconnect.php'); 
if(isset($_POST['submit'])){

$id = $_POST['id'];
$caption = $_POST['caption'];
$vcaption = mysql_real_escape_string($caption);
$source = $_POST['source'];
$vsource = mysql_real_escape_string($source);
$obid = $_POST['obid'];
$vobid = mysql_real_escape_string($obid);
$sql = "Update image Set  caption='$vcaption', source='$vsource', obid='$vobid' where id=$id ";
$result = dbcon('online',$sql);


header('Location:  imageList.php');
}
?>